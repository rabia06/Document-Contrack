package com.technest.documtree

import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.gun0912.tedpermission.provider.TedPermissionProvider


class FileHelper {

    fun RealPath(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            val proj = arrayOf(MediaStore.Images.Media.DATA)
            cursor = TedPermissionProvider.context.contentResolver.query(uri, proj, null, null, null)
            val column_index: Int = cursor?.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)!!
            cursor?.moveToFirst()
            cursor?.getString(column_index)
        } finally {
            if (cursor != null) {
                cursor.close()
            }
        }
    }
}


