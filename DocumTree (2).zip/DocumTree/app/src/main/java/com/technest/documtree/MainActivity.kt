package com.technest.documtree

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.InputStream


class MainActivity : AppCompatActivity() {

    lateinit var adapter: RecyclerViewAdp
    lateinit var recyclerView: RecyclerView
    var Auri: ArrayList<Uri> = ArrayList()
    lateinit var uri:Uri
    var  checkPermitted:Boolean = false
    var statusObjectsList: ArrayList<Any> = ArrayList()

    companion object {
        private const val ANDROID_DOCID = "primary:WhatsApp/Media/WhatsApp Images"
        private const val EXTERNAL_STORAGE_PROVIDER_AUTHORITY = "com.android.externalstorage.documents"
        private val androidUri = DocumentsContract.buildDocumentUri(
                EXTERNAL_STORAGE_PROVIDER_AUTHORITY, ANDROID_DOCID
        )
        private val androidTreeUri = DocumentsContract.buildTreeDocumentUri(
                EXTERNAL_STORAGE_PROVIDER_AUTHORITY, ANDROID_DOCID
        )
    }
    lateinit var btn:Button


    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn=findViewById(R.id.btn)
        adapter = RecyclerViewAdp(Auri)
        recyclerView=findViewById(R.id.recyclerView)
        recyclerView.setLayoutManager(LinearLayoutManager(this))
        recyclerView.adapter=adapter

        btn.setOnClickListener {
            if(checkPermitted==false)
            {
                askPermission()
            }
            else{

            }


        }
    }


    @RequiresApi(Build.VERSION_CODES.Q)
    private fun getDataForAndroid11OnlyStatus(uriMain: Uri) {
        //check for app specific folder permission granted or not
        if (checkPermitted==false) {
            askPermission()
        }
        else {


            Log.d("====", "uriMain ::: $uriMain")
            val contentResolver = contentResolver
            val buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uriMain, DocumentsContract.getDocumentId(uriMain))
            val arrayList = ArrayList<Any>()
            var cursor: Cursor? = null
            try {
                cursor = contentResolver.query(buildChildDocumentsUriUsingTree, arrayOf("document_id"), null as String?, null as Array<String?>?, null as String?)
                while (cursor!!.moveToNext()) {
                    arrayList.add(DocumentsContract.buildDocumentUriUsingTree(uriMain, cursor.getString(0)))
                    if (!DocumentsContract.buildDocumentUriUsingTree(uriMain, cursor.getString(0)).toString().endsWith(".nomedia")) {
                        val fileHelper = FileHelper()
                        val filePath: String = fileHelper.RealPath(DocumentsContract.buildDocumentUriUsingTree(uriMain, cursor.getString(0))).toString()
                        statusObjectsList.add(DocumentsContract.buildDocumentUriUsingTree(uriMain, cursor.getString(0)))
                    }
                }
                runOnUiThread {
                   statusObjectsList.size
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } catch (th: Throwable) {
                throw th
            }
        }
    }


    @RequiresApi(Build.VERSION_CODES.Q)
    private fun askPermission() {
            val storageManager =
                application.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val intent = storageManager.primaryStorageVolume.createOpenDocumentTreeIntent()
            val targetDirectory =
                "WhatsApp%2FMedia" // add your directory to be selected by the user
             uri = intent.getParcelableExtra<Uri>("android.provider.extra.INITIAL_URI") as Uri
            var scheme = uri.toString()
            scheme = scheme.replace("/root/", "/document/")
            scheme += "%3A$targetDirectory"
            uri = Uri.parse(scheme)

            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri)
            handleIntentActivityResult.launch(Intent.createChooser(intent, "Select Picture"))


    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private val handleIntentActivityResult =
        this.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode != Activity.RESULT_OK)
                return@registerForActivityResult
            val directoryUri = it.data?.data ?: return@registerForActivityResult

                contentResolver.takePersistableUriPermission(
                        directoryUri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                getPersistedUriPermissions(this@MainActivity, directoryUri.toString())
            val `is`: InputStream? = contentResolver.openInputStream(directoryUri)
            val bitmap = BitmapFactory.decodeStream(`is`)

            getDataForAndroid11OnlyStatus(it.data?.data!!)


        }




    fun getPersistedUriPermissions(
            context: Activity,
            contains: String,
    ): Boolean {     /////Check Specific Folder having permission or not

        val uriList = context.contentResolver.persistedUriPermissions
        val array: ArrayList<String> = ArrayList()
        if (uriList.size != 0) {
            for (uriPermission in uriList) {
                array.add(uriPermission.uri.toString())
            }
        }
        Log.e("permission", "getPersistedUriPermissions: $array")
        for (file in array) {
            if (file == contains) {
                checkPermitted = true
            }
        }
        return checkPermitted
    }


    private fun readSDK30(treeUri: Uri) {
        val tree = DocumentFile.fromTreeUri(this, treeUri)!!
            val uriList:ArrayList<Uri>  = arrayListOf<Uri>()
            listFiles(tree).forEach { uri ->
                uriList.add(uri)
        }
        uriList.size
    }


    fun listFiles(folder: DocumentFile): List<Uri> {
        return if (folder.isDirectory) {
            folder.listFiles().mapNotNull { file ->
                if (file.name != null) file.uri else null
            }
        } else {
            emptyList()
        }
    }

}